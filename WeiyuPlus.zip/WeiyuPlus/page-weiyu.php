<?php
/**
 * 微语页面模板
 *
 * @package custom
 * 
 * 支持后台配置主题头部尾部路径的独立页面模板
 * 启用插件时自动复制到此主题根目录
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

// 获取插件配置
$config = \Widget\Options::alloc()->plugin('WeiyuPlus');
$useThemeLayout = isset($config->useThemeLayout) ? $config->useThemeLayout : '1';
$headerDir = isset($config->headerDir) ? trim($config->headerDir) : '';
$footerDir = isset($config->footerDir) ? trim($config->footerDir) : '';

// 获取主题目录
$themeDir = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . \Widget\Options::alloc()->theme;

// 构建 header/footer 文件路径
$headerFile = $headerDir ? rtrim($themeDir . '/' . $headerDir, '/') . '/header.php' : $themeDir . '/header.php';
$footerFile = $footerDir ? rtrim($themeDir . '/' . $footerDir, '/') . '/footer.php' : $themeDir . '/footer.php';

// 检测文件是否存在
$headerExists = file_exists($headerFile);
$footerExists = file_exists($footerFile);

// 使用主题布局模式
if ($useThemeLayout === '1') {
    // 加载头部
    if ($headerExists) {
        include $headerFile;
    } else {
        // 降级方案
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="<?php \Widget\Options::alloc()->charset(); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php \Widget\Options::alloc()->title(); ?></title>
            <?php \Widget\Options::alloc()->header(); ?>
        </head>
        <body>
        <?php
    }
    ?>

    <div class="wy-container" style="max-width: 680px; margin: 0 auto; min-height: 100vh; background: #fff;">
        <?php
        // 从插件目录加载微语主文件
        $widgetPath = __TYPECHO_ROOT_DIR__ . __TYPECHO_PLUGIN_DIR__ . '/WeiyuPlus/widget-weiyu.php';
        if (file_exists($widgetPath)) {
            include $widgetPath;
        } else {
            echo '<div style="text-align:center;padding:50px;color:#999;">微语插件文件未找到</div>';
        }
        ?>
    </div>

    <?php
    // 加载尾部
    if ($footerExists) {
        include $footerFile;
    } else {
        ?>
        <?php \Widget\Options::alloc()->footer(); ?>
        </body>
        </html>
        <?php
    }
    
    // 如果 header 或 footer 未找到，显示配置提示
    if (!$headerExists || !$footerExists) {
        $missingFiles = [];
        if (!$headerExists) $missingFiles[] = 'header.php';
        if (!$footerExists) $missingFiles[] = 'footer.php';
        ?>
        <div style="position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#ff6b6b;color:#fff;padding:15px 25px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:9999;max-width:500px;text-align:center;">
            <strong>⚠️ 配置提示</strong><br>
            <span style="font-size:13px;">未找到 <?php echo implode(' 和 ', $missingFiles); ?> 文件。</span><br>
            <span style="font-size:13px;">如需嵌入主题布局，请查看主题中 header.php 和 footer.php 所在目录，并在插件后台配置对应的目录路径。</span><br>
            <button onclick="this.parentElement.remove()" style="margin-top:8px;padding:5px 15px;background:#fff;color:#ff6b6b;border:none;border-radius:4px;cursor:pointer;">关闭提示</button>
        </div>
        <?php
    }
} else {
    // 独立页面模式（不调用主题布局）
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="<?php \Widget\Options::alloc()->charset(); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>微语 - <?php \Widget\Options::alloc()->title(); ?></title>
    </head>
    <body style="margin:0;background:#f2f3f5;">
        <div class="wy-container" style="max-width: 680px; margin: 0 auto; min-height: 100vh; background: #fff;">
            <?php
            $widgetPath = __TYPECHO_ROOT_DIR__ . __TYPECHO_PLUGIN_DIR__ . '/WeiyuPlus/widget-weiyu.php';
            if (file_exists($widgetPath)) {
                include $widgetPath;
            } else {
                echo '<div style="text-align:center;padding:50px;color:#999;">微语插件文件未找到</div>';
            }
            ?>
        </div>
    </body>
    </html>
    <?php
}
?>

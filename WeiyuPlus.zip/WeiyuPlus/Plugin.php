<?php
namespace TypechoPlugin\WeiyuPlus;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Db;
use Typecho\Plugin as TypechoPlugin;
use Helper;
use Widget\Options;

/**
 * 微语 Plus
 *
 * @package WeiyuPlus
 * @author Lin.
 * @link https://linyu.live
 * @version 1.2.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class Plugin implements PluginInterface
{
    public static function activate()
    {
        $db = Db::get();
        $prefix = $db->getPrefix();

        $posts = "CREATE TABLE IF NOT EXISTS {$prefix}weiyu_posts (
            `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
            `authorId` int(10) unsigned DEFAULT '0',
            `authorName` varchar(200) DEFAULT '',
            `authorMail` varchar(200) DEFAULT '',
            `authorUrl` varchar(200) DEFAULT '',
            `title` varchar(200) DEFAULT '',
            `content` text,
            `images` text,
            `music_cover` varchar(500) DEFAULT '',
            `music_title` varchar(200) DEFAULT '',
            `music_artist` varchar(200) DEFAULT '',
            `music_link` varchar(500) DEFAULT '',
            `video_link` varchar(500) DEFAULT '',
            `video_cover` varchar(500) DEFAULT '',
            `likes` int(10) unsigned DEFAULT '0',
            `commentsNum` int(10) unsigned DEFAULT '0',
            `status` tinyint(1) unsigned DEFAULT '1',
            `created` int(10) unsigned DEFAULT '0',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

        $comments = "CREATE TABLE IF NOT EXISTS {$prefix}weiyu_comments (
            `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
            `post_id` int(10) unsigned DEFAULT '0',
            `parent_id` int(10) unsigned DEFAULT '0',
            `author` varchar(200) DEFAULT '',
            `mail` varchar(200) DEFAULT '',
            `url` varchar(200) DEFAULT '',
            `ip` varchar(64) DEFAULT '',
            `content` text,
            `created` int(10) unsigned DEFAULT '0',
            PRIMARY KEY (`id`),
            KEY `post_id` (`post_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

        $likes = "CREATE TABLE IF NOT EXISTS {$prefix}weiyu_likes (
            `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
            `post_id` int(10) unsigned DEFAULT '0',
            `user_id` int(10) unsigned DEFAULT '0',
            `guest_name` varchar(200) DEFAULT '',
            `guest_mail` varchar(200) DEFAULT '',
            `ip` varchar(64) DEFAULT '',
            `created` int(10) unsigned DEFAULT '0',
            PRIMARY KEY (`id`),
            KEY `post_id` (`post_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

        $db->query($posts);
        $db->query($comments);
        $db->query($likes);

        // 兼容旧表升级
        $cols = $db->fetchAll($db->query("SHOW COLUMNS FROM {$prefix}weiyu_posts"));
        $colNames = array_column($cols, 'Field');
        $upgrades = [
            'authorName'   => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `authorName` varchar(200) DEFAULT ''",
            'authorMail'   => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `authorMail` varchar(200) DEFAULT ''",
            'authorUrl'    => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `authorUrl` varchar(200) DEFAULT ''",
            'status'       => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `status` tinyint(1) unsigned DEFAULT '1'",
            'music_cover'  => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `music_cover` varchar(500) DEFAULT ''",
            'music_title'  => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `music_title` varchar(200) DEFAULT ''",
            'music_artist' => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `music_artist` varchar(200) DEFAULT ''",
            'music_link'   => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `music_link` varchar(500) DEFAULT ''",
            'video_link'   => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `video_link` varchar(500) DEFAULT ''",
            'video_cover'  => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `video_cover` varchar(500) DEFAULT ''",
            'title'        => "ALTER TABLE {$prefix}weiyu_posts ADD COLUMN `title` varchar(200) DEFAULT ''",
        ];
        foreach ($upgrades as $col => $sql) {
            if (!in_array($col, $colNames)) $db->query($sql);
        }

        $likeCols = $db->fetchAll($db->query("SHOW COLUMNS FROM {$prefix}weiyu_likes"));
        $likeColNames = array_column($likeCols, 'Field');
        if (!in_array('guest_name', $likeColNames)) {
            $db->query("ALTER TABLE {$prefix}weiyu_likes ADD COLUMN `guest_name` varchar(200) DEFAULT ''");
        }
        if (!in_array('guest_mail', $likeColNames)) {
            $db->query("ALTER TABLE {$prefix}weiyu_likes ADD COLUMN `guest_mail` varchar(200) DEFAULT ''");
        }

        Helper::addRoute('weiyu_index', '/weiyu', '\TypechoPlugin\WeiyuPlus\Page', 'render');
        Helper::addRoute('weiyu_page', '/weiyu/[page:digital]', '\TypechoPlugin\WeiyuPlus\Page', 'render');
        Helper::addRoute('weiyu_action', '/weiyu/action', '\TypechoPlugin\WeiyuPlus\Action', 'action');

        Helper::addPanel(3, 'WeiyuPlus/admin.php', _t('微语管理'), _t('管理微语'), 'administrator');

        // 复制页面模板到当前主题目录
        self::copyPageToTheme();

        // 插入第一条欢迎微语
        self::insertWelcomePost($db, $prefix);

        if (file_exists(__DIR__ . '/Action.php')) require_once __DIR__ . '/Action.php';
        if (file_exists(__DIR__ . '/Page.php')) require_once __DIR__ . '/Page.php';

        return _t('微语插件已激活，访问地址：/weiyu 或在后台创建独立页面选择"微语页面"模板');
    }

    public static function deactivate()
    {
        Helper::removeRoute('weiyu_index');
        Helper::removeRoute('weiyu_page');
        Helper::removeRoute('weiyu_action');
        Helper::removePanel(3, 'WeiyuPlus/admin.php');
        
        // 删除主题目录中的页面模板
        self::removePageFromTheme();
        
        return _t('微语插件已禁用');
    }

    public static function uninstall()
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $db->query("DROP TABLE IF EXISTS {$prefix}weiyu_posts");
        $db->query("DROP TABLE IF EXISTS {$prefix}weiyu_comments");
        $db->query("DROP TABLE IF EXISTS {$prefix}weiyu_likes");
        
        // 删除主题目录中的页面模板
        self::removePageFromTheme();
        
        return _t('微语插件已卸载');
    }

    public static function config(Form $form)
    {
        $cover = new Form\Element\Text('cover', NULL, '', _t('顶图链接'));
        $form->addInput($cover);

        $coverVideo = new Form\Element\Text('coverVideo', NULL, '', _t('顶图视频链接 (mp4 格式，留空则不显示视频)'));
        $form->addInput($coverVideo);

        $videoPlayMode = new Form\Element\Radio('videoPlayMode', [
            'click' => _t('点击播放'),
            'refresh' => _t('刷新页面播放一次')
        ], 'click', _t('视频播放模式'));
        $form->addInput($videoPlayMode);

        $videoFrame = new Form\Element\Radio('videoFrame', [
            'first' => _t('第一帧'),
            'last' => _t('最后一帧')
        ], 'first', _t('视频播放结束后显示的画面'));
        $form->addInput($videoFrame);

        $allowGuestPost = new Form\Element\Radio('allowGuestPost', ['0' => _t('否'), '1' => _t('是')], '1', _t('允许游客发帖'));
        $form->addInput($allowGuestPost);

        $headerDir = new Form\Element\Text('headerDir', NULL, '', _t('头部文件目录'), _t('header.php 所在目录，相对于主题根目录。留空表示在根目录，常见值：partials、templates、includes'));
        $form->addInput($headerDir);

        $footerDir = new Form\Element\Text('footerDir', NULL, '', _t('尾部文件目录'), _t('footer.php 所在目录，相对于主题根目录。留空表示在根目录，常见值：partials、templates、includes'));
        $form->addInput($footerDir);

        $useThemeLayout = new Form\Element\Radio('useThemeLayout', [
            '1' => _t('使用主题布局（调用 header/footer）'),
            '0' => _t('独立页面（不调用主题布局）')
        ], '1', _t('页面布局模式'));
        $form->addInput($useThemeLayout);
    }

    public static function personalConfig(Form $form) {}

    public static function getToken()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (empty($_SESSION['weiyu_token'])) {
            $_SESSION['weiyu_token'] = bin2hex(random_bytes(16));
        }
        return $_SESSION['weiyu_token'];
    }

    private static function copyPageToTheme()
    {
        $options = Options::alloc();
        $themeName = $options->theme;
        $themeDir = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $themeName . '/';
        
        $sourceFile = __DIR__ . '/page-weiyu.php';
        $targetFile = $themeDir . 'page-weiyu.php';
        
        // 删除主题目录中所有可能的微语页面模板
        $possibleFiles = [
            'page-weiyu.php',
            'page-weiyu-template.php',
            'page-microchat.php',
            'page-timeline.php',
            'page-dynamic.php',
            'page-moments.php'
        ];
        
        foreach ($possibleFiles as $file) {
            $filePath = $themeDir . $file;
            if (file_exists($filePath)) {
                // 检查是否是微语模板（文件内容包含微语相关标识）
                $content = file_get_contents($filePath);
                if (stripos($content, '微语') !== false || 
                    stripos($content, 'weiyu') !== false ||
                    stripos($content, 'widget-weiyu') !== false ||
                    stripos($content, 'wy-container') !== false) {
                    unlink($filePath);
                }
            }
        }
        
        // 复制新的页面模板
        if (file_exists($sourceFile)) {
            if (!is_dir(dirname($targetFile))) {
                mkdir(dirname($targetFile), 0755, true);
            }
            copy($sourceFile, $targetFile);
        }
    }

    private static function removePageFromTheme()
    {
        $options = Options::alloc();
        $themeName = $options->theme;
        
        $targetFile = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $themeName . '/page-weiyu.php';
        
        if (file_exists($targetFile)) {
            unlink($targetFile);
        }
    }

    private static function insertWelcomePost($db, $prefix)
    {
        $count = $db->fetchObject($db->select(['COUNT(id)' => 'num'])->from($prefix . 'weiyu_posts'))->num;
        if ($count > 0) {
            return;
        }

        $db->query($db->insert($prefix . 'weiyu_posts')->rows([
            'authorId'     => 0,
            'authorName'   => 'Lin.',
            'authorMail'   => '',
            'authorUrl'    => 'https://linyu.live',
            'title'        => '',
            'content'      => '<p>欢迎使用微语插件，祝你使用愉快！</p><p style="text-align:right;">—— <a href="https://linyu.live" target="_blank" style="color:#576b95;">Lin.</a></p>',
            'images'       => '',
            'music_cover'  => '',
            'music_title'  => '',
            'music_artist' => '',
            'music_link'   => '',
            'video_link'   => 'https://txmov2.a.kwimgs.com/upic/2023/09/30/20/BMjAyMzA5MzAyMDIyMjFfMjExNjM2Nzc2OV8xMTM5NTMyNjk2MzNfMl8z_b_B4cb74004bf86f15cd487f7db7d2bff07.mp4?tag=1-1779058331-sr-0-3mprb2d3ao-aa8670bfb9b7c377&clientCacheKey=3xq4ucc8jkyktgc_b.mp4&tt=b&di=8821e1f&bp=10001',
            'video_cover'  => 'https://ty2.a.kwimgs.com/upic/2023/09/30/20/BMjAyMzA5MzAyMDIyMjFfMjExNjM2Nzc2OV8xMTM5NTMyNjk2MzNfMl8z_B96ca5b2783d3a7ea01e5495c83f65d3e.jpg?tag=1-1778949686-sr-0-yxehx1gian-13c47b8c11c3972a&clientCacheKey=3xq4ucc8jkyktgc.jpg&di=8821e1f&bp=10001',
            'likes'        => 0,
            'commentsNum'  => 0,
            'status'       => 1,
            'created'      => time()
        ]));
    }

    public static function getAvatar($mail)
    {
        $mail = strtolower(trim($mail));
        if (preg_match('/^(\d+)@qq\.com$/', $mail, $m)) {
            return 'https://q.qlogo.cn/headimg_dl?dst_uin=' . $m[1] . '&spec=640';
        }
        if (preg_match('/^(\d+)@(foxmail|qq)\.com$/', $mail, $m)) {
            return 'https://q.qlogo.cn/headimg_dl?dst_uin=' . $m[1] . '&spec=640';
        }
        return 'https://gravatar.loli.net/avatar/' . md5($mail) . '?s=640&d=identicon';
    }
}

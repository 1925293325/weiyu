<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$options = \Widget\Options::alloc();
$user = \Widget\User::alloc();
$config = $options->plugin('WeiyuPlus');
$token = \TypechoPlugin\WeiyuPlus\Plugin::getToken();
$isLogin = $user->hasLogin();
$isAdmin = $isLogin && $user->pass('administrator', true);
$allowGuestPost = intval($config->allowGuestPost ?? '1');

// 自动计算 static 目录 URL（假设本文件位于插件根目录）
$pluginDir = basename(__DIR__);
$staticUrl = rtrim($options->pluginUrl, '/') . '/' . $pluginDir . '/static';
$logoUrl = $staticUrl . '/img/logo.png';

$cover = $config->cover ?: 'https://ty2.a.kwimgs.com/upic/2023/09/30/20/BMjAyMzA5MzAyMDIyMjFfMjExNjM2Nzc2OV8xMTM5NTMyNjk2MzNfMl8z_B96ca5b2783d3a7ea01e5495c83f65d3e.jpg?tag=1-1778949686-sr-0-yxehx1gian-13c47b8c11c3972a&clientCacheKey=3xq4ucc8jkyktgc.jpg&di=8821e1f&bp=10001';
$coverVideo = $config->coverVideo ?? '';
$videoPlayMode = $config->videoPlayMode ?? 'click';
$videoFrame = $config->videoFrame ?? 'first';
$nick = $isLogin ? $user->screenName : '博主';
$topAvatar = $isLogin ? \TypechoPlugin\WeiyuPlus\Plugin::getAvatar($user->mail) : $logoUrl;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>微语</title>
<link rel="stylesheet" href="<?php echo $staticUrl; ?>/style.css?v=1">
<script>
window.WEIYU_CONFIG = {
    api: '<?php echo rtrim($options->index, '/'); ?>/weiyu/action',
    token: '<?php echo $token; ?>',
    isLogin: <?php echo $isLogin ? 'true' : 'false'; ?>,
    isAdmin: <?php echo $isAdmin ? 'true' : 'false'; ?>,
    allowGuestPost: <?php echo $allowGuestPost; ?>,
    topAvatar: '<?php echo $topAvatar; ?>',
    topNick: '<?php echo htmlspecialchars($nick); ?>',
    userScreenName: '<?php echo $isLogin ? htmlspecialchars($user->screenName) : ''; ?>',
    userMail: '<?php echo $isLogin ? htmlspecialchars($user->mail) : ''; ?>',
    userUrl: '<?php echo $isLogin ? htmlspecialchars($user->url) : ''; ?>'
};
</script>
</head>
<body>

<div class="wy-wrap">
    <div class="wy-header-wrap">
        <div class="wy-cover">
            <div class="wy-cover-img" style="background-image: url('<?php echo $cover; ?>')"></div>
            <?php if (!empty($coverVideo)): ?>
            <div class="wy-cover-video" id="wy-cover-video" data-mode="<?php echo $videoPlayMode; ?>" data-frame="<?php echo $videoFrame; ?>">
                <video <?php echo ($videoPlayMode === 'refresh') ? 'autoplay' : ''; ?> muted playsinline<?php echo ($videoPlayMode === 'refresh') ? ' onloadstart="this.play()"' : ''; ?><?php echo ($videoFrame === 'last') ? ' onended="this.currentTime=this.duration-(1/this.playbackRate)"' : ''; ?>>
                    <source src="<?php echo htmlspecialchars($coverVideo); ?>" type="video/mp4">
                </video>
            </div>
            <?php endif; ?>
            <div class="wy-cover-mask"></div>
            <div class="wy-cover-meta">
                <div class="wy-cover-name" id="top-nick"><?php echo htmlspecialchars($nick); ?></div>
            </div>
            <div class="wy-cover-avatar-wrap" id="top-avatar-wrap">
                <img src="<?php echo $topAvatar; ?>" alt="" id="top-avatar-img">
            </div>
            <div class="wy-topbar">
                <span class="wy-top-btn" id="btn-login" onclick="openLogin()">登录</span>
                <span class="wy-top-btn" id="btn-post" onclick="openPostBox()" style="display:none;">发帖</span>
                <span class="wy-top-btn" id="btn-logout" onclick="doLogout()" style="display:none;">退出</span>
            </div>
        </div>
    </div>

    <div class="wy-list" id="wy-list"></div>
    <div class="wy-loading" id="wy-loading">加载中...</div>
</div>

<!-- 登录弹窗 -->
<div class="wy-modal-mask" id="login-mask" onclick="closeLogin()"></div>
<div class="wy-modal" id="login-box">
    <div class="wy-modal-close" onclick="closeLogin()">×</div>
    <h4>游客登录</h4>
    <input type="text" id="lg-name" placeholder="昵称">
    <input type="email" id="lg-mail" placeholder="邮箱">
    <input type="text" id="lg-url" placeholder="网址（可选）">
    <button onclick="doLogin()">登录</button>
</div>

<!-- 发帖大弹窗 -->
<div class="wy-post-mask" id="post-mask" onclick="closePostBox()"></div>
<div class="wy-post-box" id="post-box">
    <div class="wy-post-header">
        <button class="wy-post-cancel" onclick="closePostBox()">取消</button>
        <div class="wy-post-title">发表文字</div>
        <button class="wy-post-submit" onclick="submitPost()">发表</button>
    </div>
    <div class="wy-post-body">
        <div class="wy-post-row">
            <div class="wy-post-avatar" id="post-avatar">
                <img src="<?php echo $topAvatar; ?>" alt="">
            </div>
            <div class="wy-post-content">
                <input type="text" class="wy-post-title-input" id="post-title" placeholder="标题（可选）" maxlength="50">
                <textarea class="wy-post-textarea" id="post-content" placeholder="这一刻的想法..."></textarea>
            </div>
        </div>
    </div>
    <div class="wy-post-attachments" id="post-attachments"></div>
    <div class="wy-post-tools">
        <div class="wy-post-tool" onclick="openSub('img')">
            <svg t="1778950495769" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1689" width="200" height="200"><path d="M986.112 446.7712a38.4 38.4 0 0 0 38.4-38.4V144.128a140.9536 140.9536 0 0 0-140.8-140.8L140.7488 3.6864a140.9536 140.9536 0 0 0-140.8 140.8v735.3856a140.9536 140.9536 0 0 0 140.8 140.8l742.9632-0.4096a140.9536 140.9536 0 0 0 140.8-140.8V588.288c0-3.6864-1.1264-7.0144-2.0992-10.3936a37.8368 37.8368 0 0 0-11.9808-29.5936L785.8176 342.6304c-26.0096-23.8592-65.8432-24.576-96.2048 1.9968l-163.1232 182.8864-146.2272-84.9408a70.8608 70.8608 0 0 0-53.3504-13.6192 70.3488 70.3488 0 0 0-44.544 26.4704L179.6096 563.8656a38.4 38.4 0 0 0 55.7056 52.8384l103.8336-109.568 145.9712 84.8384c25.9584 20.0192 62.976 18.9952 91.5968-5.888l162.3552-182.1184 208.5888 191.0272v284.4672c0 35.2768-28.7232 64-64 64l-742.912 0.4096c-35.2768 0-64-28.7232-64-64V144.4864c0-35.2768 28.7232-64 64-64l742.9632-0.4096c35.2768 0 64 28.7232 64 64v264.2944c0 21.1968 17.2032 38.4 38.4 38.4z" fill="#438CFF" p-id="1690"></path><path d="M264.4992 248.4224m-49.664 0a49.664 49.664 0 1 0 99.328 0 49.664 49.664 0 1 0-99.328 0Z" fill="#438CFF" p-id="1691"></path></svg>
            图片
        </div>
        <div class="wy-post-tool" onclick="openSub('music')">
           <svg t="1779060681320" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2642" width="200" height="200"><path d="M513 138.02c50.01 0 98.49 9.78 144.08 29.06 44.08 18.64 83.68 45.35 117.7 79.37s60.73 73.63 79.37 117.7c19.28 45.59 29.06 94.07 29.06 144.08 0 50.01-9.78 98.49-29.06 144.08-18.64 44.08-45.35 83.68-79.37 117.7s-73.63 60.73-117.7 79.37c-45.59 19.28-94.07 29.06-144.08 29.06s-98.49-9.78-144.08-29.06c-44.08-18.64-83.68-45.35-117.7-79.37s-60.73-73.63-79.37-117.7c-19.28-45.59-29.06-94.07-29.06-144.08 0-50.01 9.78-98.49 29.06-144.08 18.64-44.08 45.35-83.68 79.37-117.7s73.63-60.73 117.7-79.37c45.59-19.28 94.07-29.06 144.08-29.06m0-76.35c-246.64 0-446.57 199.94-446.57 446.57 0 246.64 199.94 446.57 446.57 446.57s446.57-199.94 446.57-446.57C959.57 261.6 759.64 61.67 513 61.67z" fill="#231815" p-id="2643"></path><path d="M424.36 624.79m-148.69 0a148.69 148.69 0 1 0 297.38 0 148.69 148.69 0 1 0-297.38 0Z" fill="#F7B52C" p-id="2644"></path><path d="M677.89 426.14L556.76 692.01 417.79 628.7l168.39-369.61z" fill="#F7B52C" p-id="2645"></path><path d="M765.34 508.53L523.36 398.29l63.31-138.97z" fill="#F7B52C" p-id="2646"></path></svg>
            音乐
        </div>
        <div class="wy-post-tool" onclick="openSub('video')">
           <svg t="1778950601542" class="icon" viewBox="0 0 1241 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2715" width="200" height="200"><path d="M193.84646453 62h872.72727276c60.00000029 0 109.09090898 49.09090869 109.09090899 109.09090898v681.81818204c0 60.00000029-49.09090869 109.09090898-109.09090899 109.09090898H193.84646453c-60.00000029 0-109.09090898-49.09090869-109.09090898-109.09090898V171.09090898c0-60.00000029 49.09090869-109.09090898 109.09090898-109.09090898z" fill="#2F77F1" p-id="2716"></path><path d="M84.75555555 225.63636348h1090.90909072v54.54545449H84.75555555v-54.5454545z m673.63636377 340.90909101c9.5454545 5.4545458 15.00000029 16.36363653 15.0000003 27.27272725s-5.4545458 21.81818145-15.0000003 27.27272724L589.30101004 726.09090928c-9.5454545 5.4545458-21.81818145 5.4545458-31.36363594-1e-8-9.5454545-5.4545458-16.36363653-16.36363653-15.00000029-27.27272724V490.18181855c0-10.90909073 5.4545458-21.81818145 15.00000029-27.27272724 9.5454545-5.4545458 21.81818145-5.4545458 31.36363594 0L758.39191932 566.54545449z" fill="#AFFCFE" p-id="2717"></path></svg>
            视频
        </div>
    </div>
</div>

<!-- 图片弹框 -->
<div class="wy-sub-mask" id="sub-mask-img" onclick="closeSub('img')"></div>
<div class="wy-sub-box" id="sub-box-img">
    <div class="wy-sub-title">添加图片</div>
    <textarea class="wy-sub-input" id="sub-img-input" rows="4" placeholder="每行一个图片链接"></textarea>
    <div class="wy-sub-btns">
        <button class="wy-sub-cancel" onclick="closeSub('img')">取消</button>
        <button class="wy-sub-ok" onclick="saveSub('img')">确定</button>
    </div>
</div>

<!-- 音乐弹框 -->
<div class="wy-sub-mask" id="sub-mask-music" onclick="closeSub('music')"></div>
<div class="wy-sub-box" id="sub-box-music">
    <div class="wy-sub-title">添加音乐</div>
    <input type="text" class="wy-sub-input" id="sub-music-cover" placeholder="封面链接">
    <input type="text" class="wy-sub-input" id="sub-music-title" placeholder="歌曲名称">
    <input type="text" class="wy-sub-input" id="sub-music-artist" placeholder="歌手">
    <input type="text" class="wy-sub-input" id="sub-music-link" placeholder="音乐链接 (mp3)">
    <div class="wy-sub-btns">
        <button class="wy-sub-cancel" onclick="closeSub('music')">取消</button>
        <button class="wy-sub-ok" onclick="saveSub('music')">确定</button>
    </div>
</div>

<!-- 视频弹框 -->
<div class="wy-sub-mask" id="sub-mask-video" onclick="closeSub('video')"></div>
<div class="wy-sub-box" id="sub-box-video">
    <div class="wy-sub-title">添加视频</div>
    <input type="text" class="wy-sub-input" id="sub-video-link" placeholder="视频链接 (mp4)">
    <input type="text" class="wy-sub-input" id="sub-video-cover" placeholder="视频封面链接">
    <div class="wy-sub-btns">
        <button class="wy-sub-cancel" onclick="closeSub('video')">取消</button>
        <button class="wy-sub-ok" onclick="saveSub('video')">确定</button>
    </div>
</div>

<!-- 评论弹窗 -->
<div class="wy-input-mask" id="input-mask" onclick="closeComment()"></div>
<div class="wy-input-box" id="input-box">
    <div class="wy-input-meta" id="cm-meta">
        <input type="text" id="cm-author" placeholder="昵称">
        <input type="email" id="cm-mail" placeholder="邮箱">
        <input type="text" id="cm-url" placeholder="网址">
    </div>
    <textarea id="cm-text" placeholder="评论..."></textarea>
    <div style="overflow:hidden;">
        <span class="wy-input-hint" id="cm-hint"></span>
        <button onclick="submitCm()">发送</button>
    </div>
</div>

<script src="<?php echo $staticUrl; ?>/script.js?v=1"></script>
</body>
</html>

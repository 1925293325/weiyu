const API = window.WEIYU_CONFIG.api;
const TOKEN = window.WEIYU_CONFIG.token;
const TYPECHO_LOGIN = window.WEIYU_CONFIG.isLogin;
const IS_ADMIN = window.WEIYU_CONFIG.isAdmin;
const ALLOW_GUEST_POST = window.WEIYU_CONFIG.allowGuestPost;
let currentPage = 1, totalPage = 1, isLoading = false, replyTo = 0, activePostId = 0;

// 音频全局
let wyAudio = null;
let wyAudioId = null;

// 发帖附件数据
let postData = { images: '', musicCover: '', musicTitle: '', musicArtist: '', musicLink: '', videoLink: '', videoCover: '' };

function checkGuestLogin() {
    try {
        const name = localStorage.getItem('wy_guest_name');
        const mail = localStorage.getItem('wy_guest_mail');
        return !!(name && mail);
    } catch (e) { return false; }
}

function getGuestInfo() {
    try {
        return {
            name: localStorage.getItem('wy_guest_name') || '',
            mail: localStorage.getItem('wy_guest_mail') || '',
            url: localStorage.getItem('wy_guest_url') || ''
        };
    } catch (e) { return { name: '', mail: '', url: '' }; }
}

function getCurrentAvatar() {
    if (TYPECHO_LOGIN) return window.WEIYU_CONFIG.topAvatar;
    const g = getGuestInfo();
    if (g.mail) {
        const mail = g.mail.toLowerCase().trim();
        if (/^(\d+)@qq\.com$/.test(mail)) {
            return 'https://q.qlogo.cn/headimg_dl?dst_uin=' + mail.match(/^(\d+)@qq\.com$/)[1] + '&spec=100';
        }
        return 'https://gravatar.loli.net/avatar/' + hexMD5(mail) + '?s=200&d=identicon';
    }
    return 'https://gravatar.loli.net/avatar/000?s=200&d=identicon';
}

function getCurrentName() {
    if (TYPECHO_LOGIN) return window.WEIYU_CONFIG.topNick;
    const g = getGuestInfo();
    return g.name || '游客';
}

/* MD5 */
function hexMD5(string) {
    function RotateLeft(lValue, iShiftBits) {
        return (lValue<<iShiftBits) | (lValue>>>(32-iShiftBits));
    }
    function AddUnsigned(lX,lY) {
        var lX4,lY4,lX8,lY8,lResult;
        lX8 = (lX & 0x80000000);
        lY8 = (lY & 0x80000000);
        lX4 = (lX & 0x40000000);
        lY4 = (lY & 0x40000000);
        lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF);
        if (lX4 & lY4) return (lResult ^ 0x80000000 ^ lY8 ^ lX8);
        if (lX4 | lY4) {
            if (lResult & 0x40000000) return (lResult ^ 0xC0000000 ^ lY8 ^ lX8);
            else return (lResult ^ 0x40000000 ^ lY8 ^ lX8);
        } else return (lResult ^ lY8 ^ lX8);
    }
    function F(x,y,z) { return (x & y) | ((~x) & z); }
    function G(x,y,z) { return (x & z) | (y & (~z)); }
    function H(x,y,z) { return (x ^ y ^ z); }
    function I(x,y,z) { return (y ^ (x | (~z))); }
    function FF(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }
    function GG(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }
    function HH(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }
    function II(a,b,c,d,x,s,ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }
    function ConvertToWordArray(string) {
        var lWordCount;
        var lMessageLength = string.length;
        var lNumberOfWords_temp1=lMessageLength + 8;
        var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64;
        var lNumberOfWords = (lNumberOfWords_temp2+1)*16;
        var lWordArray=Array(lNumberOfWords-1);
        var lBytePosition = 0;
        var lByteCount = 0;
        while ( lByteCount < lMessageLength ) {
            lWordCount = (lByteCount-(lByteCount % 4))/4;
            lBytePosition = (lByteCount % 4)*8;
            lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount)<<lBytePosition));
            lByteCount++;
        }
        lWordCount = (lByteCount-(lByteCount % 4))/4;
        lBytePosition = (lByteCount % 4)*8;
        lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80<<lBytePosition);
        lWordArray[lNumberOfWords-2] = lMessageLength<<3;
        lWordArray[lNumberOfWords-1] = lMessageLength>>>29;
        return lWordArray;
    }
    function WordToHex(lValue) {
        var WordToHexValue="",WordToHexValue_temp="",lByte,lCount;
        for (lCount = 0;lCount<=3;lCount++) {
            lByte = (lValue>>>(lCount*8)) & 255;
            WordToHexValue_temp = "0" + lByte.toString(16);
            WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2);
        }
        return WordToHexValue;
    }
    var x=Array();
    var k,AA,BB,CC,DD,a,b,c,d;
    var S11=7, S12=12, S13=17, S14=22;
    var S21=5, S22=9 , S23=14, S24=20;
    var S31=4, S32=11, S33=16, S34=23;
    var S41=6, S42=10, S43=15, S44=21;
    string = unescape(encodeURIComponent(string));
    x = ConvertToWordArray(string);
    a = 0x67452301; b = 0xEFCDAB89; c = 0x98BADCFE; d = 0x10325476;
    for (k=0;k<x.length;k+=16) {
        AA=a; BB=b; CC=c; DD=d;
        a=FF(a,b,c,d,x[k+0], S11,0xD76AA478);
        d=FF(d,a,b,c,x[k+1], S12,0xE8C7B756);
        c=FF(c,d,a,b,x[k+2], S13,0x242070DB);
        b=FF(b,c,d,a,x[k+3], S14,0xC1BDCEEE);
        a=FF(a,b,c,d,x[k+4], S11,0xF57C0FAF);
        d=FF(d,a,b,c,x[k+5], S12,0x4787C62A);
        c=FF(c,d,a,b,x[k+6], S13,0xA8304613);
        b=FF(b,c,d,a,x[k+7], S14,0xFD469501);
        a=FF(a,b,c,d,x[k+8], S11,0x698098D8);
        d=FF(d,a,b,c,x[k+9], S12,0x8B44F7AF);
        c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);
        b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);
        a=FF(a,b,c,d,x[k+12],S11,0x6B901122);
        d=FF(d,a,b,c,x[k+13],S12,0xFD987193);
        c=FF(c,d,a,b,x[k+14],S13,0xA679438E);
        b=FF(b,c,d,a,x[k+15],S14,0x49B40821);
        a=GG(a,b,c,d,x[k+1], S21,0xF61E2562);
        d=GG(d,a,b,c,x[k+6], S22,0xC040B340);
        c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);
        b=GG(b,c,d,a,x[k+0], S24,0xE9B6C7AA);
        a=GG(a,b,c,d,x[k+5], S21,0xD62F105D);
        d=GG(d,a,b,c,x[k+10],S22,0x2441453);
        c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);
        b=GG(b,c,d,a,x[k+4], S24,0xE7D3FBC8);
        a=GG(a,b,c,d,x[k+9], S21,0x21E1CDE6);
        d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);
        c=GG(c,d,a,b,x[k+3], S23,0xF4D50D87);
        b=GG(b,c,d,a,x[k+8], S24,0x455A14ED);
        a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);
        d=GG(d,a,b,c,x[k+2], S22,0xFCEFA3F8);
        c=GG(c,d,a,b,x[k+7], S23,0x676F02D9);
        b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);
        a=HH(a,b,c,d,x[k+5], S31,0xFFFA3942);
        d=HH(d,a,b,c,x[k+8], S32,0x8771F681);
        c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);
        b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);
        a=HH(a,b,c,d,x[k+1], S31,0xA4BEEA44);
        d=HH(d,a,b,c,x[k+4], S32,0x4BDECFA9);
        c=HH(c,d,a,b,x[k+7], S33,0xF6BB4B60);
        b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);
        a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);
        d=HH(d,a,b,c,x[k+0], S32,0xEAA127FA);
        c=HH(c,d,a,b,x[k+3], S33,0xD4EF3085);
        b=HH(b,c,d,a,x[k+6], S34,0x4881D05);
        a=HH(a,b,c,d,x[k+9], S31,0xD9D4D039);
        d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);
        c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);
        b=HH(b,c,d,a,x[k+2], S34,0xC4AC5665);
        a=II(a,b,c,d,x[k+0], S41,0xF4292244);
        d=II(d,a,b,c,x[k+7], S42,0x432AFF97);
        c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);
        b=II(b,c,d,a,x[k+5], S44,0xFC93A039);
        a=II(a,b,c,d,x[k+12],S41,0x655B59C3);
        d=II(d,a,b,c,x[k+3], S42,0x8F0CCC92);
        c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D);
        b=II(b,c,d,a,x[k+1], S44,0x85845DD1);
        a=II(a,b,c,d,x[k+8], S41,0x6FA87E4F);
        d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);
        c=II(c,d,a,b,x[k+6], S43,0xA3014314);
        b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);
        a=II(a,b,c,d,x[k+4], S41,0xF7537E82);
        d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);
        c=II(c,d,a,b,x[k+2], S43,0x2AD7D2BB);
        b=II(b,c,d,a,x[k+9], S44,0xEB86D391);
        a=AddUnsigned(a,AA); b=AddUnsigned(b,BB); c=AddUnsigned(c,CC); d=AddUnsigned(d,DD);
    }
    var temp = WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
    return temp.toLowerCase();
}

function updateLoginUI() {
    const isGuest = checkGuestLogin();
    const btnLogin = document.getElementById('btn-login');
    const btnPost = document.getElementById('btn-post');
    const btnLogout = document.getElementById('btn-logout');

    const canPost = IS_ADMIN || (ALLOW_GUEST_POST && (TYPECHO_LOGIN || isGuest));

    if (TYPECHO_LOGIN || isGuest) {
        btnLogin.style.display = 'none';
        btnLogout.style.display = 'inline-block';
        btnPost.style.display = canPost ? 'inline-block' : 'none';
        document.getElementById('top-nick').textContent = getCurrentName();
        const avatar = getCurrentAvatar();
        if (avatar) {
            document.getElementById('top-avatar-img').src = avatar;
            document.querySelector('#post-avatar img').src = avatar;
        }
    } else {
        btnLogin.style.display = 'inline-block';
        btnPost.style.display = 'none';
        btnLogout.style.display = 'none';
    }
}

/* ===== 发帖弹框 ===== */
function openPostBox() {
    if (!checkGuestLogin() && !TYPECHO_LOGIN) { openLogin(); return; }
    postData = { images: '', musicCover: '', musicTitle: '', musicArtist: '', musicLink: '', videoLink: '', videoCover: '' };
    document.getElementById('post-title').value = '';
    document.getElementById('post-content').value = '';
    updateAttachTags();
    document.getElementById('post-mask').classList.add('show');
    document.getElementById('post-box').classList.add('show');
    setTimeout(() => document.getElementById('post-content').focus(), 100);
}

function closePostBox() {
    document.getElementById('post-mask').classList.remove('show');
    document.getElementById('post-box').classList.remove('show');
}

function openSub(type) {
    document.getElementById('sub-mask-' + type).classList.add('show');
    document.getElementById('sub-box-' + type).classList.add('show');
    if (type === 'img') document.getElementById('sub-img-input').value = postData.images;
    if (type === 'music') {
        document.getElementById('sub-music-cover').value = postData.musicCover;
        document.getElementById('sub-music-title').value = postData.musicTitle;
        document.getElementById('sub-music-artist').value = postData.musicArtist;
        document.getElementById('sub-music-link').value = postData.musicLink;
    }
    if (type === 'video') {
        document.getElementById('sub-video-link').value = postData.videoLink;
        document.getElementById('sub-video-cover').value = postData.videoCover;
    }
}

function closeSub(type) {
    document.getElementById('sub-mask-' + type).classList.remove('show');
    document.getElementById('sub-box-' + type).classList.remove('show');
}

function saveSub(type) {
    if (type === 'img') {
        postData.images = document.getElementById('sub-img-input').value.trim();
    }
    if (type === 'music') {
        postData.musicCover = document.getElementById('sub-music-cover').value.trim();
        postData.musicTitle = document.getElementById('sub-music-title').value.trim();
        postData.musicArtist = document.getElementById('sub-music-artist').value.trim();
        postData.musicLink = document.getElementById('sub-music-link').value.trim();
    }
    if (type === 'video') {
        postData.videoLink = document.getElementById('sub-video-link').value.trim();
        postData.videoCover = document.getElementById('sub-video-cover').value.trim();
    }
    updateAttachTags();
    closeSub(type);
}

function updateAttachTags() {
    const box = document.getElementById('post-attachments');
    let html = '';
    if (postData.images) {
        const count = postData.images.split('\n').filter(l => l.trim()).length;
        html += `<span class="wy-attach-tag">🖼️ ${count}张图片<span class="wy-attach-del" onclick="clearAttach('images')">×</span></span>`;
    }
    if (postData.musicLink) {
        html += `<span class="wy-attach-tag">🎵 ${postData.musicTitle || '音乐'}<<span class="wy-attach-del" onclick="clearAttach('music')">×</span></span>`;
    }
    if (postData.videoLink) {
        html += `<span class="wy-attach-tag">🎬 视频<span class="wy-attach-del" onclick="clearAttach('video')">×</span></span>`;
    }
    box.innerHTML = html;
}

function clearAttach(key) {
    if (key === 'images') postData.images = '';
    if (key === 'music') { postData.musicCover = ''; postData.musicTitle = ''; postData.musicArtist = ''; postData.musicLink = ''; }
    if (key === 'video') { postData.videoLink = ''; postData.videoCover = ''; }
    updateAttachTags();
}

async function submitPost() {
    const title = document.getElementById('post-title').value.trim();
    const content = document.getElementById('post-content').value.trim();
    const imgCount = postData.images.split('\n').filter(l => l.trim()).length;
    if (imgCount > 4) return toast('最多只能上传 4 张图片');
    if (!content && !postData.images && !postData.musicLink && !postData.videoLink && !title) return toast('写点什么吧');

    const g = getGuestInfo();
    const body = `title=${encodeURIComponent(title)}` +
        `&content=${encodeURIComponent(content)}` +
        `&images=${encodeURIComponent(postData.images)}` +
        `&music_cover=${encodeURIComponent(postData.musicCover)}` +
        `&music_title=${encodeURIComponent(postData.musicTitle)}` +
        `&music_artist=${encodeURIComponent(postData.musicArtist)}` +
        `&music_link=${encodeURIComponent(postData.musicLink)}` +
        `&video_link=${encodeURIComponent(postData.videoLink)}` +
        `&video_cover=${encodeURIComponent(postData.videoCover)}` +
        `&guest_name=${encodeURIComponent(g.name)}&guest_mail=${encodeURIComponent(g.mail)}&guest_url=${encodeURIComponent(g.url)}`;

    try {
        const res = await fetch(`${API}?do=publish&_=${TOKEN}`, {
            method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body
        });
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { console.error('发布解析失败:', text); toast('发布失败'); return; }
        if (json.code === 200) {
            closePostBox();
            toast(json.msg);
            loadPosts(1);
        } else if (json.code === 401) {
            toast('请先登录');
        } else {
            toast(json.msg || '发布失败');
        }
    } catch(e) { toast('发布失败'); }
}

/* ===== 登录 ===== */
function openLogin() {
    document.getElementById('login-mask').classList.add('show');
    document.getElementById('login-box').classList.add('show');
}
function closeLogin() {
    document.getElementById('login-mask').classList.remove('show');
    document.getElementById('login-box').classList.remove('show');
}
function doLogin() {
    const name = document.getElementById('lg-name').value.trim();
    const mail = document.getElementById('lg-mail').value.trim();
    const url = document.getElementById('lg-url').value.trim();
    if (!name || !mail) return alert('请填写昵称和邮箱');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return alert('邮箱格式不正确');
    try {
        localStorage.setItem('wy_guest_name', name);
        localStorage.setItem('wy_guest_mail', mail);
        localStorage.setItem('wy_guest_url', url);
    } catch (e) {}
    closeLogin();
    updateLoginUI();
    toast('登录成功');
    loadPosts(1);
}
function doLogout() {
    try {
        localStorage.removeItem('wy_guest_name');
        localStorage.removeItem('wy_guest_mail');
        localStorage.removeItem('wy_guest_url');
    } catch (e) {}
    updateLoginUI();
    toast('已退出登录');
    setTimeout(() => location.reload(), 800);
}

function toast(msg) {
    const t = document.createElement('div'); t.className = 'wy-toast'; t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), 1800);
}

document.addEventListener('DOMContentLoaded', () => {
    updateLoginUI();
    loadPosts();
    
    // 顶图视频点击播放处理
    const videoContainer = document.getElementById('wy-cover-video');
    if (videoContainer) {
        const mode = videoContainer.getAttribute('data-mode');
        const video = videoContainer.querySelector('video');
        
        if (mode === 'click' && video) {
            videoContainer.style.cursor = 'pointer';
            videoContainer.addEventListener('click', () => {
                if (video.paused) {
                    video.currentTime = 0;
                    video.play();
                }
            });
            
            video.addEventListener('ended', () => {
                const frame = videoContainer.getAttribute('data-frame');
                if (frame === 'last') {
                    video.currentTime = video.duration - (1 / video.playbackRate);
                }
            });
        }
    }
    
    window.addEventListener('scroll', () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 180) {
            if (!isLoading && currentPage < totalPage) loadPosts(currentPage + 1);
        }
    });
    document.addEventListener('click', (e) => {
    });
});

async function loadPosts(page = 1) {
    if (isLoading) return;
    isLoading = true;
    document.getElementById('wy-loading').textContent = '加载中...';
    try {
        const res = await fetch(`${API}?do=getPosts&page=${page}`);
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { console.error('JSON解析失败:', text); throw e; }
        if (json.code === 200) {
            totalPage = json.totalPage; currentPage = page;
            const list = document.getElementById('wy-list');
            if (page === 1) list.innerHTML = '';
            if (json.data.length === 0 && page === 1) list.innerHTML = '<div style="text-align:center;padding:60px;color:#ccc;">还没有微语</div>';
            json.data.forEach(post => list.appendChild(createItem(post)));
            const ld = document.getElementById('wy-loading');
            if (currentPage >= totalPage) ld.textContent = json.total > 0 ? '— 到底了 —' : '';
            else ld.textContent = '';
        } else {
            console.error('API错误:', json);
        }
    } catch (e) { console.error(e); document.getElementById('wy-loading').textContent = '加载失败'; }
    isLoading = false;
}

function createItem(post) {
    const div = document.createElement('div'); div.className = 'wy-item'; div.id = `post-${post.id}`;

    let imgHtml = '';
    if (post.images && post.images.length > 0) {
        const c = post.images.length;
        let cls = 'g3';
        if (c === 1) cls = 'g1';
        else if (c === 2 || c === 4) cls = 'g2';
        else if (c >= 5) cls = 'g' + (c > 9 ? 9 : c);
        imgHtml = `<div class="wy-imgs ${cls}">${post.images.map((img, i) => `<img src="${img}" onclick="previewImage('${img}', ${JSON.stringify(post.images)}, ${i})" loading="lazy" alt="">`).join('')}</div>`;
    }

    let musicHtml = '';
    if (post.music_link) {
        const coverUrl = post.music_cover || 'https://via.placeholder.com/100';
        musicHtml = `<div class="wy-music" id="music-${post.id}" onclick="toggleMusic(${post.id}, '${post.music_link}')">
            <div class="wy-music-cover">
                <img src="${coverUrl}" alt="">
                <div class="overlay">
                    <div class="play-btn">
                        <svg class="icon-play" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        <svg class="icon-pause" viewBox="0 0 24 24" style="display:none;"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
                    </div>
                </div>
                <div class="note-wrap"><svg class="note-icon" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg></div>
            </div>
            <div class="wy-music-info">
                <div class="wy-music-bg" style="background-image: url('${coverUrl}');"></div>
                <div class="wy-music-content">
                    <div class="wy-music-title">${escapeHtml(post.music_title || '未知歌曲')}</div>
                    <div class="wy-music-artist">${escapeHtml(post.music_artist || '未知歌手')}</div>
                </div>
            </div>
        </div>`;
    }

    let videoHtml = '';
    if (post.video_link) {
        videoHtml = `<div class="wy-video">
            <video controls autoplay muted playsinline poster="${post.video_cover || ''}" src="${post.video_link}" preload="metadata"></video>
        </div>`;
    }

    let likesHtml='';if(post.like_list&&post.like_list.length>0){const names=post.like_list.map(lk=>`<span class="lk-name">${escapeHtml(lk.name)}</span>`).join('<span class="lk-sep">，</span>');likesHtml=`<div class="wy-likes"><svg class="lk-heart" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>${names}</div>`;}

    let cmHtml = '';
    if (post.comments && post.comments.length > 0) {
       const cmItems=post.comments.map(c=>{const reply=c.is_child?`<span class="cm-re"> 回复 </span><span class="cm-to">${escapeHtml(c.parent_name)}</span>`:'';return`<div class="wy-cm" onclick="replyCm(${post.id},${c.id},'${escapeHtml(c.author)}')"><div class="cm-body"><span class="cm-name">${escapeHtml(c.author)}</span>${reply}：${escapeHtml(c.content)}</div></div>`;}).join('');

        cmHtml = `<div class="wy-cm-list">${cmItems}</div>`;
    }

    const delBtn = post.can_delete ? `<span class="wy-del" onclick="event.stopPropagation();deletePost(${post.id})">删除</span>` : '';
    const isAuthor = post.authorId > 0;

    div.innerHTML = `
        <div class="wy-item-header">
            <div class="wy-item-avatar"><img src="${post.author_avatar}" alt=""></div>
            <div class="wy-item-meta">
                <div class="wy-item-nick">${escapeHtml(post.author_name)}</div>
                ${isAuthor ? `<div class="wy-item-badge show" title="博主"><svg t="1779054523655" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4231"><path d="M956.672 459.776L862.72 397.568c-16.64-11.008-24.832-30.976-20.992-50.688l22.272-110.592c4.096-20.736-2.304-42.24-17.152-57.344-15.104-15.104-36.352-21.504-57.344-17.152l-110.592 22.272c-19.712 4.096-39.424-4.352-50.688-20.992L565.76 69.12c-11.776-17.664-31.488-28.16-52.736-28.16s-40.96 10.496-52.736 28.16l-62.464 93.952c-11.008 16.64-30.976 24.832-50.688 20.992l-110.592-22.272c-20.736-4.096-42.24 2.304-57.344 17.152-15.104 15.104-21.504 36.352-17.152 57.344l22.272 110.592c3.84 19.712-4.352 39.424-20.992 50.688l-93.952 62.464c-17.664 11.776-28.16 31.488-28.16 52.736s10.496 40.96 28.16 52.736l93.952 62.464c16.64 11.008 24.832 30.976 20.992 50.688l-22.272 110.592c-4.096 20.736 2.304 42.24 17.152 57.344 15.104 15.104 36.352 21.504 57.344 17.152l110.592-22.272c19.712-4.096 39.424 4.352 50.688 20.992l62.464 93.952c11.776 17.664 31.488 28.16 52.736 28.16s40.96-10.496 52.736-28.16l62.464-93.952c11.008-16.64 30.976-24.832 50.688-20.992l110.592 22.272c20.736 4.096 42.24-2.304 57.344-17.152 15.104-15.104 21.504-36.352 17.152-57.344l-22.272-110.592c-3.84-19.712 4.352-39.424 20.992-50.688l93.952-62.464c17.664-11.776 28.16-31.488 28.16-52.736s-10.496-41.216-28.16-52.992z m-249.344-22.016l-211.456 215.04c-5.888 6.144-13.824 9.216-22.016 9.216-7.168 0-14.592-2.56-20.224-7.68l-138.24-122.112c-12.8-11.264-13.824-30.72-2.816-43.264 11.264-12.8 30.72-13.824 43.264-2.816l116.48 102.912 190.976-194.304c11.776-12.032 31.232-12.288 43.52-0.256 12.288 11.52 12.288 30.976 0.512 43.264z" fill="#5396FF" p-id="4232"></path></svg></div>` : ''}
            </div>
        </div>
        ${post.title ? `<div class="wy-item-title">${escapeHtml(post.title)}</div>` : ''}
        <div class="wy-item-text">${post.content.includes('<') ? linkifyHtml(post.content) : linkifyHtml(escapeHtml(post.content))}</div>
        <div class="wy-item-media">
            ${imgHtml}
            ${videoHtml}
        </div>
        ${musicHtml}
        <div class="wy-info">
            <div class="wy-time">${post.created_format} ${delBtn}</div>
            <div style="display:flex;align-items:center;">
                <div class="wy-like-wrap" onclick="doLike(${post.id})">
                    <svg class="wy-like-icon ${post.has_liked ? 'liked' : ''}" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    <span class="wy-like-count">${post.likes || 0}</span>
                </div>
               <svg class="wy-comment-icon" viewBox="0 0 24 24" onclick="openComment(${post.id})"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
            </div>
        </div>
        ${(likesHtml || cmHtml) ? `<div class="wy-social">${likesHtml}${cmHtml}</div>` : ''}
    `;
    return div;
}

async function doLike(id) {
    if (!checkGuestLogin() && !TYPECHO_LOGIN) { openLogin(); return; }
    const g = getGuestInfo();
    try {
        const res = await fetch(`${API}?do=like&post_id=${id}&guest_name=${encodeURIComponent(g.name)}&guest_mail=${encodeURIComponent(g.mail)}&_=${TOKEN}`);
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { console.error('点赞解析失败:', text); toast('操作失败'); return; }
        if (json.code === 200) { loadPosts(1); }
        else { toast(json.msg || '操作失败'); }
    } catch ( e) { toast('操作失败'); }
}

/* ===== 音乐播放/暂停 ===== */
function toggleMusic(id, url) {
    if (wyAudio && wyAudioId === id) {
        if (wyAudio.paused) {
            wyAudio.play().catch(() => toast('播放失败'));
            setMusicPlaying(id, true);
        } else {
            wyAudio.pause();
            setMusicPlaying(id, false);
        }
        return;
    }
    if (wyAudio) {
        wyAudio.pause();
        setMusicPlaying(wyAudioId, false);
        wyAudio = null;
    }
    const audio = new Audio(url);
    audio.onended = () => {
        setMusicPlaying(id, false);
        wyAudio = null; wyAudioId = null;
    };
    audio.onerror = () => {
        toast('播放失败');
        setMusicPlaying(id, false);
        wyAudio = null; wyAudioId = null;
    };
    audio.play().then(() => {
        wyAudio = audio;
        wyAudioId = id;
        setMusicPlaying(id, true);
    }).catch(() => {
        toast('播放失败');
    });
}

function setMusicPlaying(id, playing) {
    const el = document.getElementById('music-' + id);
    if (!el) return;
    if (playing) {
        el.classList.add('playing');
        el.querySelector('.icon-play').style.display = 'none';
        el.querySelector('.icon-pause').style.display = 'block';
    } else {
        el.classList.remove('playing');
        el.querySelector('.icon-play').style.display = 'block';
        el.querySelector('.icon-pause').style.display = 'none';
    }
}

function openComment(postId) {
    if (!checkGuestLogin() && !TYPECHO_LOGIN) { openLogin(); return; }
    activePostId = postId; replyTo = 0;
    const metaRow = document.getElementById('cm-meta');
    const hint = document.getElementById('cm-hint');

    if (TYPECHO_LOGIN) {
        metaRow.style.display = 'none';
        hint.textContent = window.WEIYU_CONFIG.isLogin ? ('以 ' + window.WEIYU_CONFIG.userScreenName + ' 的身份评论') : '';
    } else if (checkGuestLogin()) {
        metaRow.style.display = 'none';
        const g = getGuestInfo();
        hint.textContent = `以 ${g.name} 的身份评论`;
    } else {
        metaRow.style.display = 'flex';
        hint.textContent = '';
        const iden = loadIdentity();
        document.getElementById('cm-author').value = iden.author;
        document.getElementById('cm-mail').value = iden.mail;
        document.getElementById('cm-url').value = iden.url;
    }

    document.getElementById('cm-text').value = '';
    document.getElementById('input-mask').classList.add('show');
    document.getElementById('input-box').classList.add('show');
    setTimeout(() => document.getElementById('cm-text').focus(), 100);
}

function closeComment() {
    document.getElementById('input-mask').classList.remove('show');
    document.getElementById('input-box').classList.remove('show');
    activePostId = 0; replyTo = 0;
}

function replyCm(postId, cmId, author) {
    openComment(postId);
    replyTo = cmId;
    setTimeout(() => {
        const ta = document.getElementById('cm-text');
        ta.placeholder = `回复 ${author}：`; ta.focus();
    }, 100);
}

async function submitCm() {
    if (!activePostId) return;
    const text = document.getElementById('cm-text').value.trim();
    if (!text) return toast('请输入内容');

    let author, mail, url;
    if (TYPECHO_LOGIN) {
        author = window.WEIYU_CONFIG.userScreenName;
        mail = window.WEIYU_CONFIG.userMail;
        url = window.WEIYU_CONFIG.userUrl;
    } else if (checkGuestLogin()) {
        const g = getGuestInfo(); author = g.name; mail = g.mail; url = g.url;
    } else {
        author = document.getElementById('cm-author').value.trim();
        mail = document.getElementById('cm-mail').value.trim();
        url = document.getElementById('cm-url').value.trim();
        if (!author || !mail) return toast('请填写昵称和邮箱');
        saveIdentity(author, mail, url);
    }

    const body = `post_id=${activePostId}&parent_id=${replyTo || 0}&content=${encodeURIComponent(text)}&author=${encodeURIComponent(author)}&mail=${encodeURIComponent(mail)}&url=${encodeURIComponent(url)}`;
    try {
        const res = await fetch(`${API}?do=comment&_=${TOKEN}`, {
            method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body
        });
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { console.error('评论解析失败:', text); toast('提交失败'); return; }
        if (json.code === 200) { closeComment(); toast('评论成功'); loadPosts(1); }
        else { toast(json.msg || '提交失败'); }
    } catch (e) { toast('提交失败'); }
}

async function deletePost(id) {
    if (!confirm('确定删除这条微语？')) return;
    try {
        const res = await fetch(`${API}?do=delete&id=${id}&_=${TOKEN}`);
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { console.error('删除解析失败:', text); toast('删除失败'); return; }
        if (json.code === 200) { document.getElementById(`post-${id}`)?.remove(); toast('已删除'); }
        else toast(json.msg || '删除失败');
    } catch (e) { toast('删除失败'); }
}

function loadIdentity() {
    try { return { author: localStorage.getItem('wy_author') || '', mail: localStorage.getItem('wy_mail') || '', url: localStorage.getItem('wy_url') || '' }; } catch (e) { return { author: '', mail: '', url: '' }; }
}
function saveIdentity(author, mail, url) {
    try { localStorage.setItem('wy_author', author); localStorage.setItem('wy_mail', mail); localStorage.setItem('wy_url', url || ''); } catch (e) {}
}

function escapeHtml(t) { if (!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
function linkifyHtml(t) {
    if (!t) return '';
    if (t.includes('<')) {
        return t.replace(/(?<!["'=\]])\b(https?:\/\/[^\s<<>"']+)(?=["'\s<<]|$)/gi, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
    }
    return t.replace(/\b(https?:\/\/[^\s<<>"']+)(?=["'\s<<]|$)/gi, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
}

let previewIndex = 0;
let previewImages = [];
function previewImage(url, images = null, index = 0) {
    previewImages = images || [url];
    previewIndex = index;
    const dots = previewImages.map((_, i) => `<span class="wy-preview-dot${i === index ? ' active' : ''}" data-index="${i}"></span>`).join('');
    const o = document.createElement('div'); o.className = 'wy-overlay'; o.id = 'wy-preview-overlay';
    o.innerHTML = `<img src="${previewImages[previewIndex]}" alt="" id="wy-preview-img"><div class="wy-preview-nav">${dots}</div><button class="wy-preview-btn" onclick="prevImage()">‹</button><button class="wy-preview-btn next" onclick="nextImage()">›</button>`;
    o.onclick = (e) => { if (e.target === o) o.remove(); };
    document.body.appendChild(o);
}
function prevImage() { if (previewIndex > 0) { previewIndex--; updatePreview(); } }
function nextImage() { if (previewIndex < previewImages.length - 1) { previewIndex++; updatePreview(); } }
function updatePreview() {
    const overlay = document.getElementById('wy-preview-overlay');
    if (!overlay) return;
    overlay.querySelector('#wy-preview-img').src = previewImages[previewIndex];
    overlay.querySelectorAll('.wy-preview-dot').forEach((dot, i) => {
        dot.classList.toggle('active', i === previewIndex);
    });
}
